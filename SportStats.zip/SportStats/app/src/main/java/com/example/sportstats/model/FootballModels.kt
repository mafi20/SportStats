package com.example.sportstats.model

// Odpowiedź listy meczów z football-data.org: /v4/competitions/{id}/matches
data class FootballMatchesResponse(
    val matches: List<FootballMatch>?
)

data class FootballMatch(
    val id: Int,
    val utcDate: String?,
    val status: String?,
    val homeTeam: FootballTeam?,
    val awayTeam: FootballTeam?,
    val score: FootballScore?
)

data class FootballTeam(
    val id: Int?,
    val name: String?,
    val shortName: String?
)

data class FootballScore(
    val winner: String?,
    val fullTime: FootballFullTime?
)

data class FootballFullTime(
    val home: Int?,
    val away: Int?
)
