package com.example.sportstats.model

// Odpowiedź z endpointu /matches-results/{tournament_id} (Tennis Live Data, RapidAPI)
data class TennisMatchesResponse(
    val data: TennisMatchesData?
)

data class TennisMatchesData(
    val matches: List<TennisMatch>?
)

data class TennisMatch(
    val id: Int?,
    val status: String?,
    val round_name: String?,
    val date: String?,
    val home: TennisPlayer?,
    val away: TennisPlayer?,
    val result: TennisResult?
)

data class TennisPlayer(
    val name: String?,
    val id: Int?
)

data class TennisResult(
    val winner: String?
)

// Odpowiedź z /tours
data class TennisToursResponse(
    val data: TennisToursData?
)

data class TennisToursData(
    val tours: List<TennisTour>?
)

data class TennisTour(
    val tour_code: String?,
    val tour_season_id: Int?,
    val name: String?
)
