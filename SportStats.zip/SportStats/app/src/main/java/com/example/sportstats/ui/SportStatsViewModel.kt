package com.example.sportstats.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.sportstats.BuildConfig
import com.example.sportstats.network.RetrofitClient
import kotlinx.coroutines.launch

enum class Sport { FOOTBALL, TENNIS }

// Prosty, jednolity model wiersza wyświetlanego na liście - niezależnie od źródła danych
data class MatchRow(
    val label: String,
    val detail: String
)

class SportStatsViewModel : ViewModel() {

    var selectedSport by mutableStateOf(Sport.FOOTBALL)
        private set

    // Kod ligi (football-data.org) lub ID turnieju (tennis-live-data)
    var queryInput by mutableStateOf("PL")
        private set

    var isLoading by mutableStateOf(false)
        private set

    var errorMessage by mutableStateOf<String?>(null)
        private set

    var results by mutableStateOf<List<MatchRow>>(emptyList())
        private set

    fun onSportSelected(sport: Sport) {
        selectedSport = sport
        queryInput = if (sport == Sport.FOOTBALL) "PL" else ""
        results = emptyList()
        errorMessage = null
    }

    fun onQueryInputChanged(value: String) {
        queryInput = value
    }

    fun fetchData() {
        errorMessage = null
        isLoading = true
        viewModelScope.launch {
            try {
                results = when (selectedSport) {
                    Sport.FOOTBALL -> fetchFootball()
                    Sport.TENNIS -> fetchTennis()
                }
                if (results.isEmpty()) {
                    errorMessage = "Brak wyników do wyświetlenia (sprawdź kod ligi / ID turnieju lub limit API)."
                }
            } catch (e: Exception) {
                errorMessage = "Błąd pobierania danych: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    private suspend fun fetchFootball(): List<MatchRow> {
        val apiKey = BuildConfig.FOOTBALL_DATA_API_KEY
        require(apiKey.isNotBlank()) { "Brak klucza FOOTBALL_DATA_API_KEY w gradle.properties" }

        val code = queryInput.ifBlank { "PL" }
        val response = RetrofitClient.footballApi.getMatches(
            apiKey = apiKey,
            competitionCode = code
        )
        return response.matches.orEmpty().map { match ->
            val home = match.homeTeam?.shortName ?: match.homeTeam?.name ?: "?"
            val away = match.awayTeam?.shortName ?: match.awayTeam?.name ?: "?"
            MatchRow(
                label = "$home vs $away",
                detail = "Status: ${match.status ?: "?"} | Data: ${match.utcDate ?: "?"}"
            )
        }
    }

    private suspend fun fetchTennis(): List<MatchRow> {
        val apiKey = BuildConfig.RAPIDAPI_KEY
        require(apiKey.isNotBlank()) { "Brak klucza RAPIDAPI_KEY w gradle.properties" }

        val tournamentId = queryInput.toIntOrNull()
            ?: throw IllegalArgumentException("Podaj liczbowe ID turnieju (znajdziesz je przez endpoint /tournaments)")

        val response = RetrofitClient.tennisApi.getMatchResults(
            apiKey = apiKey,
            tournamentId = tournamentId
        )
        return response.data?.matches.orEmpty().map { match ->
            val home = match.home?.name ?: "?"
            val away = match.away?.name ?: "?"
            MatchRow(
                label = "$home vs $away",
                detail = "Runda: ${match.round_name ?: "?"} | Status: ${match.status ?: "?"}"
            )
        }
    }
}
