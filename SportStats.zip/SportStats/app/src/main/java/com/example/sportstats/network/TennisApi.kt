package com.example.sportstats.network

import com.example.sportstats.model.TennisMatchesResponse
import com.example.sportstats.model.TennisToursResponse
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path

// Dokumentacja: https://rapidapi.com/sportcontentapi/api/tennis-live-data
interface TennisApi {

    @GET("tours")
    suspend fun getTours(
        @Header("X-RapidAPI-Key") apiKey: String,
        @Header("X-RapidAPI-Host") host: String = "tennis-live-data.p.rapidapi.com"
    ): TennisToursResponse

    @GET("matches-results/{tournamentId}")
    suspend fun getMatchResults(
        @Header("X-RapidAPI-Key") apiKey: String,
        @Header("X-RapidAPI-Host") host: String = "tennis-live-data.p.rapidapi.com",
        @Path("tournamentId") tournamentId: Int
    ): TennisMatchesResponse
}
