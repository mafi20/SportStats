package com.example.sportstats

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.sportstats.ui.MatchRow
import com.example.sportstats.ui.Sport
import com.example.sportstats.ui.SportStatsViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: SportStatsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SportStatsScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun SportStatsScreen(viewModel: SportStatsViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SportStats",
            style = MaterialTheme.typography.headlineMedium
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Wybór dyscypliny
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = viewModel.selectedSport == Sport.FOOTBALL,
                onClick = { viewModel.onSportSelected(Sport.FOOTBALL) },
                label = { Text("Piłka nożna") }
            )
            FilterChip(
                selected = viewModel.selectedSport == Sport.TENNIS,
                onClick = { viewModel.onSportSelected(Sport.TENNIS) },
                label = { Text("Tenis") }
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = viewModel.queryInput,
            onValueChange = viewModel::onQueryInputChanged,
            label = {
                Text(
                    if (viewModel.selectedSport == Sport.FOOTBALL)
                        "Kod ligi (np. PL, PD, SA, BL1, FL1)"
                    else
                        "ID turnieju (liczba, z endpointu /tournaments)"
                )
            },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = { viewModel.fetchData() },
            enabled = !viewModel.isLoading,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (viewModel.isLoading) "Pobieranie..." else "Pobierz dane")
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (viewModel.isLoading) {
            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }

        viewModel.errorMessage?.let { error ->
            Text(
                text = error,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.padding(vertical = 8.dp)
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(viewModel.results) { row: MatchRow ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(row.label, style = MaterialTheme.typography.titleMedium)
                        Text(row.detail, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}
