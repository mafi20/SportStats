package com.example.sportstats.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

object RetrofitClient {

    private fun buildClient(): OkHttpClient {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        return OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(15, TimeUnit.SECONDS)
            .build()
    }

    val footballApi: FootballApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://api.football-data.org/")
            .client(buildClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FootballApi::class.java)
    }

    val tennisApi: TennisApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://tennis-live-data.p.rapidapi.com/")
            .client(buildClient())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(TennisApi::class.java)
    }
}
