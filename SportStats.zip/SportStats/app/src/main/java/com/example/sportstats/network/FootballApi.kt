package com.example.sportstats.network

import com.example.sportstats.model.FootballMatchesResponse
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Path
import retrofit2.http.Query

// Dokumentacja: https://www.football-data.org/documentation/api
interface FootballApi {

    // Przykładowe kody lig: PL (Premier League), PD (La Liga), SA (Serie A),
    // BL1 (Bundesliga), FL1 (Ligue 1), CL (Liga Mistrzów)
    @GET("v4/competitions/{competitionCode}/matches")
    suspend fun getMatches(
        @Header("X-Auth-Token") apiKey: String,
        @Path("competitionCode") competitionCode: String,
        @Query("status") status: String = "SCHEDULED"
    ): FootballMatchesResponse
}
