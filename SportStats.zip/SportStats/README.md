# SportStats – aplikacja Android

Prosta aplikacja (Kotlin + Jetpack Compose), która pobiera dane sportowe z dwóch oficjalnych, darmowych API:

- **Piłka nożna** – [football-data.org](https://www.football-data.org/) (REST API, oficjalne, darmowy plan)
- **Tenis** – [Tennis Live Data (RapidAPI)](https://rapidapi.com/sportcontentapi/api/tennis-live-data) (oficjalne API, darmowy plan: 250 zapytań/mies.)

Świadomie użyłem oficjalnych API zamiast scrapowania stron www — scraping jest niestabilny (strony zmieniają HTML), wolniejszy w utrzymaniu i często łamie regulamin serwisu. Jeśli mimo wszystko wolisz scraping konkretnej strony, daj znać którą stronę masz na myśli, a dopiszę osobny moduł do tego.

## Jak uruchomić

### 1. Zdobądź klucze API (za darmo)
- Piłka nożna: zarejestruj się na https://www.football-data.org/client/register — otrzymasz klucz e-mailem.
- Tenis: załóż konto na https://rapidapi.com, wejdź na stronę [Tennis Live Data](https://rapidapi.com/sportcontentapi/api/tennis-live-data), wybierz plan Basic (darmowy) i skopiuj swój `X-RapidAPI-Key`.

### 2. Skonfiguruj klucze
Skopiuj plik `gradle.properties.example` jako `gradle.properties` (w głównym katalogu projektu) i wklej tam swoje klucze:

```
FOOTBALL_DATA_API_KEY=twoj_klucz
RAPIDAPI_KEY=twoj_klucz
```

### 3. Otwórz w Android Studio
- Otwórz folder `SportStats` jako projekt w Android Studio (najnowsza wersja).
- Android Studio automatycznie zsynchronizuje Gradle i pobierze zależności (wymaga internetu przy pierwszym uruchomieniu).
- Uruchom na emulatorze lub telefonie (przycisk ▶).

### 4. Korzystanie z aplikacji
- Wybierz dyscyplinę (Piłka nożna / Tenis).
- Dla piłki nożnej: wpisz kod ligi, np. `PL` (Premier League), `PD` (La Liga), `SA` (Serie A), `BL1` (Bundesliga), `FL1` (Ligue 1).
- Dla tenisa: wpisz numeryczne ID turnieju. Żeby je znaleźć, możesz tymczasowo dodać wywołanie `RetrofitClient.tennisApi.getTours(...)` i podejrzeć listę w logach — dopiszę do tego wygodniejszy ekran, jeśli będzie potrzebny.
- Kliknij "Pobierz dane" — lista meczów pojawi się poniżej.

## Struktura projektu
```
app/src/main/java/com/example/sportstats/
├── MainActivity.kt          # UI w Jetpack Compose
├── model/                    # Modele danych (JSON -> Kotlin)
├── network/                  # Retrofit: interfejsy API + klient
└── ui/                        # ViewModel ze stanem ekranu i logiką pobierania
```

## Budowanie APK w chmurze (bez instalowania niczego)

Ten projekt zawiera gotowy workflow GitHub Actions (`.github/workflows/build-apk.yml`), który buduje APK automatycznie na serwerach GitHub. Wszystko robisz przez przeglądarkę.

1. **Załóż konto na GitHub** (jeśli nie masz) – https://github.com/signup — darmowe.
2. **Stwórz nowe, prywatne repozytorium** – przycisk "New" na stronie głównej GitHub.
3. **Wgraj pliki projektu** – na stronie repozytorium kliknij "Add file" → "Upload files" i przeciągnij tam całą zawartość folderu `SportStats` (wypakowaną z zip).
4. **Dodaj klucze API jako sekrety** (Settings → Secrets and variables → Actions → "New repository secret"):
   - `FOOTBALL_DATA_API_KEY` – Twój klucz z football-data.org
   - `RAPIDAPI_KEY` – Twój klucz z RapidAPI (Tennis Live Data)
5. **Uruchom budowanie** – zakładka "Actions" na górze repozytorium → wybierz "Build APK" → "Run workflow".
6. **Poczekaj ok. 2-5 minut**, aż build się zakończy (zielony ptaszek).
7. **Pobierz APK** – kliknij zakończony build → w sekcji "Artifacts" na dole pobierz `SportStats-apk` (to plik .zip zawierający APK).
8. **Zainstaluj na telefonie** – rozpakuj, prześlij plik `app-debug.apk` na telefon (np. przez Google Drive/mail), otwórz go i zainstaluj. Telefon poprosi o zgodę na "instalowanie z nieznanych źródeł" – zaakceptuj tylko dla tego pliku.

Wszystko to możesz zrobić nawet z samego telefonu, jeśli GitHub obsłuży upload plików w przeglądarce mobilnej.

## Co dalej
Gdy powiesz jaki ma być "system" liczenia prawdopodobieństwa, dopiszę:
- logikę analizującą pobrane dane (np. na bazie formy, H2H, statystyk),
- ekran z wynikiem/prawdopodobieństwem dla wybranego meczu.
